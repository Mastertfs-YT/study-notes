# Study Notes Site

This is a simple static website created from study notes.

## How to Use

1. Clone or download this repository.
2. The site can be viewed by opening `index.html` in a web browser.
3. To deploy using GitHub Pages:
    - Go to repository Settings > Pages.
    - Select the `main` branch and root (`/`) folder.
    - Your site will be available at `https://your-username.github.io/study-notes-site/`
